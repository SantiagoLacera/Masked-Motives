Masked Motives is a 2D Isometric video game where the player's goal is to get away with the murder of their old mentor. 

Installation Steps:

1. Download the project files
2. Find the location of the downloaded files 
3. Click to launch the executable


Known, unfixed bugs:

	Ice Slide Mini-game: every other key press is not detected. 
	Options menu in game stopped returning back to menu. 
	Some items don't pick up correctly. 
	Returning back from mini-games, inside a tile that has an exterior collider. 


List of 3rd-party items:
	
	Various Genres Music Collection Free
		-> License: Extension Asset
		-> Link: https://assetstore.unity.com/packages/audio/music/various-genres-music-			collection-free-191462

	Ink Integration for Unity: 
		-> License: Extension Asset
		-> Link: https://assetstore.unity.com/packages/tools/integration/ink-integration-for-			unity-60055

	UX Flat Icons:
	 	-> License: Extension Asset
		-> Link https://assetstore.unity.com/packages/2d/gui/icons/ux-flat-icons-free-202525

	RPG Essentials Sound Effects: 
		-> License: Extension Asset
		-> Link: https://assetstore.unity.com/packages/audio/sound-fx/rpg-essentials-sound-			effects-free-227708

	Valid Wordle Words:
		-> License: N/A
		-> Link: https://gist.github.com/dracos/dd0668f281e685bad51479e5acaadb93
	
	Ice Dungeon Tileset: 
		-> License: OGA-BY 3.0
		-> Link: https://opengameart.org/content/ice-dungeon
	
	Fruit+:
		-> License: CC-BY 4.0
		-> Link: https://ninjikin.itch.io/fruit

	Pixelsnorf's Free Platformer Slimes:
		-> License: N/A
		-> Link: https://pixelsnorf.itch.io/platformer-slimes

	Pixelarium asset pack:
		-> License: Free version License
		-> Link: https://lukepolice.itch.io/pixelariumgrasslands

	8-Bit Forest Theme:
		-> License: Public Domain CC0
		-> Link: https://opengameart.org/content/8-bit-forest-theme
		
	Arctic Beat:
		-> License: CC-BY 4.0
		-> Link: https://opengameart.org/content/arctic-beat
	
	Desert Theme:
		-> License: Public Domain CC0
		-> Link: https://opengameart.org/content/desert-theme-8bit-chiptune-theme


	2D Pixel Art Icons | fruits:
		-> License: Extension Asset
		-> Link: https://assetstore.unity.com/packages/2d/gui/icons/2d-pixel-art-icons-				fruits-258332
	2D Pizel Art Icon | Swords:
		-> License: Extension Asset
		-> Link: https://assetstore.unity.com/packages/2d/gui/icons/2d-pixel-art-icons-				swords-259620

	2D Pixel Medieval Weapons:
		-> License: Extension Asset
		-> Link: https://assetstore.unity.com/packages/2d/2d-pixel-medieval-weapons-275774
	
	Pixel Art Gem Pack-Animated:
		-> License: Extension Asset
		-> Link: https://assetstore.unity.com/packages/2d/2d-pixel-medieval-weapons-275774

	Isometric Tiles:
		-> License: CC0 1. Universal
		-> Link: https://devilsworkshop.itch.io/isometric-tiles-pixel-art

	